<template>
  <NuxtPage />
</template>
